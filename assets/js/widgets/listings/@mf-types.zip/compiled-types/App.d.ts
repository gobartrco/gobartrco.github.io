import "./index.css";
export declare const App: () => import("react/jsx-runtime").JSX.Element;
export declare const mount: (containerId: string) => void;
